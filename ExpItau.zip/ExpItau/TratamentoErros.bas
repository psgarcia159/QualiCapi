Attribute VB_Name = "TratamentoErros"
Option Explicit

'Declara constantes a serem usadas como par�metro _
'da chamada  da fun��o de tratamento de erros.

Global Const ComMensagem = True
Global Const SemMensagem = False

'Declara as contantes de Tratamento de Erros

Global Const ErrOutros = 1
Global Const ErrFalhaConexao = 2
Global Const ErrChaveDuplicada = 3
Global Const ErrRegistroAlterado = 4
Global Const ErrRegistroExcluido = 5
Global Const ErrTipoInvalido = 6
Global Const ErrRegistroBloqueado = 7
Global Const ErrChaveNula = 8
Global Const ErrCamposObrigatorios = 9
Global Const ErrExclusaoRelacionamento = 10
Global Const ErrTabelaRelacionada = 11
Global Const ErrRegistroJaAlterado = 12
Public Function funTrataErrosAccess(TipoTratamento As String) As Integer
    
    ' Esta rotina verifica os erros ocorridos
    ' durante a execu��o com o banco de dados Access
    
    Select Case Errors(0).Number
    
    
    Case 3201, 3200
        If TipoTratamento Then
            MsgBox "O registro n�o pode ser exclu�do pois est� relacionado com outras tabelas.", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrTabelaRelacionada
    
    Case 3022
        If TipoTratamento Then
            MsgBox "Este registro j� foi cadastrado.", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrChaveDuplicada
    
    Case 3024
        If TipoTratamento Then
            MsgBox "Banco de Dados " & NomeSgbd & " n�o encontrado", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrFalhaConexao
    
    Case 3006
        If TipoTratamento Then
            MsgBox "O Banco de Dados " & NomeSgbd & " est� indispon�vel", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrFalhaConexao
    
    Case 3197
        If TipoTratamento Then
            MsgBox "Este registro foi alterado ou exclu�do por outro usu�rio", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrRegistroExcluido
    
    Case 3421
        If TipoTratamento Then
            MsgBox "Tipo de dado inv�lido", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrTipoInvalido
    
    Case 3058
        If TipoTratamento Then
            MsgBox "Chave prim�ria ou �ndice com valor nulo", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrChaveNula
    
    Case 3314
        If TipoTratamento Then
            MsgBox "Favor preencher campos obrigat�rios", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrCamposObrigatorios
    
    Case 3315
        If TipoTratamento Then
            MsgBox "Favor preencher campos obrigat�rios", vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrCamposObrigatorios
    
      Case Else 'Outros erros n�o listados
        If TipoTratamento Then
            MsgBox "Erro n� " & Err & ": " & Err.Description, vbCritical, "ATEN��O"
        End If
        funTrataErrosAccess = ErrOutros
    
    End Select

End Function

Public Function funTrataErrosSqlServer(TipoTratamento As String) As Integer
   
   ' Esta rotina verifica os erros ocorridos
   ' durante a execu��o com o banco de dados SQL Server
   
   Dim ErroOdbc As String
   Dim nuErro As Integer
   Dim dsSQLstate As String
   Dim Descricao As String
   
'======================================================================================================================
' TRATAMENTO DE ERRO PARA ADO
    Select Case Conexao.Errors(0).NativeError
        Case 2627
            If TipoTratamento Then
                MsgBox "N�o � possivel concluir a grava��o." & Chr(10) & _
                       "A tabela j� possui registros cadastrados", _
                       vbCritical + vbApplicationModal + vbOKOnly, "ATEN��O"
            End If
            funTrataErrosSqlServer = ErrTabelaRelacionada
        Case -2147467262
            If TipoTratamento Then
                MsgBox "Arquivo n�o Encontrado.", vbCritical + vbOKOnly, "ATEN��O"
            End If
            funTrataErrosSqlServer = ErrTabelaRelacionada
        Case Else   'quando for um novo erro
            If TipoTratamento Then
                MsgBox "Ocorreu o seguinte Erro" & Chr(10) & Chr(10) & _
                       "Erro n�..:" & Err.Number & Chr(10) & Chr(10) & _
                       "Descri��o:" & Err.Description, vbCritical, "ATEN��O"
            End If
            funTrataErrosSqlServer = ErrOutros
    End Select
'   '* Erro no RDO
'   If rdoEngine.rdoErrors.Count <> 0 Then
'
'    If (rdoEngine.rdoErrors(0).SQLRetcode <> rdSQLSuccess And _
'        rdoEngine.rdoErrors(0).SQLRetcode <> rdSQLSuccessWithInfo) Then
'
'        '* Erro na ODBC
'
'            dsSQLstate = rdoEngine.rdoErrors(0).SQLState
'            nuErro = rdoEngine.rdoErrors(0).Number
'            Descricao = rdoEngine.rdoErrors(0).Description
'
'        Select Case dsSQLstate
'
'        Case "01000"
'
'            '* Chave duplicada ou tentativa de excluir registro pai;
'            ' comando abortado pelo SQL Server
'
'            If (nuErro = 3621) Then
'
'                ' Tentativa de excluir um registro que � chave prim�ria em
'                ' outra tabela
'
'                If InStr(rdoEngine.rdoErrors(1).Description, "DELETE") <> 0 Then
'                    If TipoTratamento Then
'                        MsgBox "Este registro n�o pode ser exclu�do, pois existem tabelas a ele associadas ", vbCritical, "ATEN��O"
'                    End If
'                    funTrataErrosSqlServer = ErrExclusaoRelacionamento
'                    rdoErrors.Clear
'                End If
'
'                ' Tentativa de alterar a chave prim�ria do registro para
'                ' um valor j� existente na tabela
'
'                If InStr(rdoEngine.rdoErrors(1).Description, "UPDATE") <> 0 Or _
'                    rdoEngine.rdoErrors(1).Number = 2627 Then
'                    If TipoTratamento Then
'                        MsgBox "Este registro j� foi cadastrado.", vbCritical, "ATEN��O"
'                    End If
'                    funTrataErrosSqlServer = ErrChaveDuplicada
'                    rdoErrors.Clear
'                End If
'
'            Else 'Outros erros n�o listados
'
'                If TipoTratamento Then
'                    MsgBox "Erro n� " & nuErro & ": " & Descricao, vbCritical, "ATEN��O"
'                End If
'                funTrataErrosSqlServer = ErrOutros
'
'            End If
'
'        Case "01S03"
'            '* Tentativa de atualizar ou excluir registro que
'            '  ja foi excluido por outro usuario
'            If TipoTratamento Then
'                MsgBox "Este registro foi exclu�do por outro usu�rio", vbCritical, "ATEN��O"
'            End If
'            funTrataErrosSqlServer = ErrRegistroExcluido
'
'        Case "37000"
'            '* Tentativa de atualizar registro que
'            '  ja foi alterado por outro usuario
'            If (nuErro = 16934) Then
'                '* Tentativa de atualizar ou excluir registro que
'                '  ja foi excluido por outro usuario
'                If TipoTratamento Then
'                    MsgBox "Este registro foi alterado por outro usu�rio", vbCritical, "ATEN��O"
'                End If
'                funTrataErrosSqlServer = ErrRegistroAlterado
'            Else 'Outros erros n�o listados
'                If TipoTratamento Then
'                    MsgBox "Erro n� " & nuErro & ": " & Descricao, vbCritical, "ATEN��O"
'                End If
'                funTrataErrosSqlServer = ErrOutros
'            End If
'
'          Case "S1T00"
'            '* A tabela esta bloqueada por outro usuario,
'            '  nao conseguiu criar o ResultSet
'            If TipoTratamento Then
'                MsgBox "A tabela esta bloqueada por outro usuario. Tente mais tarde.", vbCritical, "ATEN��O"
'            End If
'            funTrataErrosSqlServer = ErrChaveDuplicada
'
'        Case Else
'            '* Outro erro ODBC
'            If TipoTratamento Then
'                MsgBox "Erro n� " & nuErro & ": " & Descricao, vbCritical, "ATEN��O"
'            End If
'            funTrataErrosSqlServer = ErrOutros
'        End Select
'
'    Else
'        'O tratamento abaixo foi comentado para evitar uma repeti��o do tratamento de erros
'        'no grid, pois este � feito tamb�m pelo controle de dados
'        '* Erro de Execucao do programa
'         'MsgBox "Erro n� " & Err & ": " & Err.Description, vbCritical, "ATEN��O"
'    End If
'
'End If
    
End Function
Public Function funTrataErros(TipoTratamento As String) As Integer

    'Verifica qual o tipo de acesso que est� sendo utilizado

    Select Case NomeSgbd
    Case "Access"
            funTrataErros = funTrataErrosAccess(TipoTratamento)
    Case "Sql Server"
            funTrataErros = funTrataErrosSqlServer(TipoTratamento)
    End Select

End Function

