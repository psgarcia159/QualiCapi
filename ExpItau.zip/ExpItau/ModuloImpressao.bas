Attribute VB_Name = "ModuloImpressao"
Option Explicit
Global AltRodape As Single       'Vari�vel usada para calcular tamanho da p�gina (refere-se a altura ocupada pelo rodap�)
Global AltCabecalho As Single       'Vari�vel usada para calcular tamanho da p�gina (refere-se a altura ocupada pelo cabe�alho)
Sub subImprimeListagemGRID(xOrientacao As Integer, xGrid As TrueOleDBGrid70.PrintInfo, Texto As String)
    With xGrid
        ' Setar margens a depender do tipo de impress�o
        If xOrientacao = 1 Then
            .SettingsOrientation = 1
            .SettingsMarginTop = 567
            '.SettingsMarginBottom = 630
            .SettingsMarginBottom = 750
            '.SettingsMarginLeft = 1134
            .SettingsMarginLeft = 750
            .SettingsMarginRight = 567
        Else
            .SettingsOrientation = 2
            .SettingsMarginTop = 1134
            '.SettingsMarginBottom = 630
            .SettingsMarginBottom = 750
            .SettingsMarginLeft = 567
            '.SettingsMarginRight = 567
            .SettingsMarginRight = 850
       End If
        
        'Determina se o cabe�alho ser� definido pelo usu�rio e o seu tamanho
        'Neste caso o cabe�alho ser� definido pelo usu�rio atrav�s de API
        '.PageHeaderOwnerDraw = True
        '.PageHeaderHeight = 4000
        
        ' Setar o cabe�alho
        .PageHeaderFont.Name = "Arial"
        .PageHeaderFont.Size = 12
        .PageHeaderFont.Bold = True
        .PageHeader = Texto + " \t\t" + CStr(Now)
        
        ' O Cabe�alho e o rodap� devem aparecer em todas as p�ginas
        .RepeatColumnHeaders = True
        .RepeatColumnFooters = True
        
        ' Imprimir texto no rodap�
        .PageFooter = "QUALIDADOS\t\tP�gina: \p/\P"
        
        ' Chamar o Preview de impress�o
        .PageSetup
        '.PrintPreview
    End With
    If Not xGrid.PageSetupCancelled Then
        xGrid.PrintPreview
    End If
    

End Sub

Sub subImprimeListagemGRIDUnBound(xOrientacao As Integer, xGrid As TrueDBGrid70.PrintInfo, Texto As String)
    With xGrid
        ' Setar margens a depender do tipo de impress�o
        If xOrientacao = 1 Then
            .SettingsOrientation = 1
            .SettingsMarginTop = 567
            '.SettingsMarginBottom = 630
            .SettingsMarginBottom = 750
            '.SettingsMarginLeft = 1134
            .SettingsMarginLeft = 750
            .SettingsMarginRight = 567
        Else
            .SettingsOrientation = 2
            .SettingsMarginTop = 1134
            '.SettingsMarginBottom = 630
            .SettingsMarginBottom = 750
            .SettingsMarginLeft = 567
            '.SettingsMarginRight = 567
            .SettingsMarginRight = 850
       End If
        
        'Determina se o cabe�alho ser� definido pelo usu�rio e o seu tamanho
        'Neste caso o cabe�alho ser� definido pelo usu�rio atrav�s de API
        '.PageHeaderOwnerDraw = True
        '.PageHeaderHeight = 4000
        
        ' Setar o cabe�alho
        .PageHeaderFont.Name = "Arial"
        .PageHeaderFont.Size = 12
        .PageHeaderFont.Bold = True
        .PageHeader = Texto + " \t\t" + CStr(Now)
        
        ' O Cabe�alho e o rodap� devem aparecer em todas as p�ginas
        .RepeatColumnHeaders = True
        .RepeatColumnFooters = True
        
        ' Imprimir texto no rodap�
        .PageFooter = "QUALIDADOS\t\tP�gina: \p/\P"
        
        ' Chamar o Preview de impress�o
        .PageSetup
        '.PrintPreview
    End With
    If Not xGrid.PageSetupCancelled Then
        xGrid.PrintPreview
    End If
    

End Sub

Function funTamanhoTextoPrinter(Texto As String, Escala As Integer, Fonte As String, TamLetra As Long) As Single
    Printer.ScaleMode = Escala
    Printer.FontName = Fonte
    Printer.FontSize = TamLetra
    funTamanhoTextoPrinter = Printer.TextWidth(Texto)
End Function
Sub subQuebraTexto(Texto As String, XInicio As Single, TamCampo As Single, TamLetra As Long, Fonte As String, Negrito As Boolean, Italico As Boolean)
    Dim Resto As String
    Dim ProcuraEspaco As Integer
        
    'Para Garantir Que Vai Verificar o Tamanho Com a Formata��o Correta
    Printer.Font.Name = Fonte
    Printer.Font.Size = TamLetra
    Printer.Font.Bold = Negrito
    Printer.Font.Italic = Italico
    
    Resto = ""
    Texto = Trim$(Texto)
    'Texto � uma vari�vel que indica a string a ser impressa, ap�s a impress�o o seu valor �
    'substitu�do pelo valor de Resto, se n�o existir Resto significa que j� foi impresso toda a
    'string, consequentemente o valor de texto tamb�m ser� vazio.
    
    'Se Texto for vazio imprime vazio e sai
    If Texto = "" Then
        subImprimeTexto Texto, XInicio, Printer.CurrentY, TamLetra, Fonte, Negrito, Italico
        'subImprimeTexto Texto, XInicio, YInicio, TamLetra, Fonte, Negrito, Italico
        Exit Sub
    End If
    
    While Texto <> ""
        'Enquanto o tamanho do Texto for maior que o tamanho do espa�o reservado para ele
        'ser� retirado o �ltimo caractere do Texto e este ser� acrescido a vari�vel Resto
        While Printer.TextWidth(Texto) > TamCampo
            Resto = Mid$(Texto, Len(Texto), 1) + Resto
            Texto = Mid$(Texto, 1, (Len(Texto) - 1))
        Wend
        
'*********************************************************************************************************
'Esta parte da sub � para impedir que se quebre uma palavra no meio
'*********************************************************************************************************
        'Se Resto for igual a vazio significa que n�o existir� uma pr�xima linha
        If Resto <> "" Then
            If Mid$(Resto, 1, 1) = " " Then 'Resto possui espa�o no in�cio quebrou uma palavra completa
                Resto = LTrim$(Resto)
            ElseIf Mid$(Texto, Len(Texto), 1) = " " Then 'Texto possui espa�o no fim
                Texto = RTrim$(Texto)                           'quebrou uma palavra completa
            Else 'Quebrou metade de uma palavra
                ProcuraEspaco = Len(Texto)
                'Verifica se Texto possui algum espa�o para quebrar a palavra completa
                While Mid$(Texto, ProcuraEspaco, 1) <> " " And ProcuraEspaco <> 1
                    ProcuraEspaco = ProcuraEspaco - 1
                Wend
                If ProcuraEspaco <> 1 Then
                    Resto = Right$(Texto, Len(Texto) - ProcuraEspaco) & Resto
                    Texto = RTrim$(Left(Texto, ProcuraEspaco))
                End If
            End If
        End If
'*********************************************************************************************************
        subImprimeTexto Texto, XInicio, Printer.CurrentY, TamLetra, Fonte, Negrito, Italico
        Texto = Resto
        Resto = ""
    Wend
End Sub

'*************************

Function funTamanhoTexto(Texto As String) As Single
    Dim XSeguidas As Integer, X As Integer, ContLinhas As Integer
    X = 1
    XSeguidas = 1
    ContLinhas = 1
    While X <> Len(Texto)
        If Mid$(Texto, X, 1) = Chr$(13) Then
            ContLinhas = ContLinhas + 1
            XSeguidas = 0
        End If
        If XSeguidas \ 80 <> 0 Then
            ContLinhas = ContLinhas + 1
            XSeguidas = 0
        End If
        X = X + 1
        XSeguidas = XSeguidas + 1
    Wend
    funTamanhoTexto = ContLinhas * 0.4
End Function

Sub subImprimeBox(XInicio As Single, YInicio As Single, XFim As Single, YFim As Single)
    Printer.DrawWidth = 1
    Printer.Line (XInicio, YInicio)-(XFim, YFim), QBColor(0), B
End Sub

Function subRetornaImpNum(Texto As String, XInicio As Single, TamCampo As Single, TamLetra As Long, Fonte As String, Negrito As Boolean, Italico As Boolean) As Single
    
    'Para Garantir Que Vai Verificar o Tamanho Com a Formata��o Correta
    Printer.Font.Name = Fonte
    Printer.Font.Size = TamLetra
    Printer.Font.Bold = Negrito
    Printer.Font.Italic = Italico
    subRetornaImpNum = XInicio + (TamCampo - Printer.TextWidth(Texto))
End Function
Sub subRodape(XInicio As Single, YInicio As Single, ByVal NomeRelatorio As String)
    Dim IniciaImp As Single
    AltRodape = 2.5
    Printer.CurrentY = YInicio - AltRodape
    
    If Printer.Orientation = 1 Then
        subImprimeLinha XInicio, 20, 6
        IniciaImp = Printer.CurrentY + 0.2
'        subImprimeTexto NomeRelatorio, XInicio, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "DATA: " & Format(Date, "dd/mm/yy"), 13, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "HORA: " & Format(Time, "HH:MM:SS"), 15.2, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "P�GINA: " & Printer.Page, 17.5, IniciaImp, 8, "Times New Roman", False, False
    Else
        subImprimeLinha XInicio, 29, 6
        IniciaImp = Printer.CurrentY + 0.2
'        subImprimeTexto NomeRelatorio, XInicio, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "DATA: " & Format(Date, "dd/mm/yy"), 21, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "HORA: " & Format(Time, "HH:MM:SS"), 23.2, IniciaImp, 8, "Times New Roman", False, False
        subImprimeTexto "P�GINA: " & Printer.Page, 25.5, IniciaImp, 8, "Times New Roman", False, False
    End If
End Sub
Sub subImprimeCelula(XData As Object, IniCaixaX As Single, FimCaixaX As Single, IniCaixaY As Single, Largura As Single, Titulo As String, DistanciaTitCampo As Single, xcampo As String, Negrito As Boolean)
'    Dim FimCaixaY As Single, GuardaY As Single, RecebeCampo As Variant
'
'    FimCaixaY = IniCaixaY + Largura
'    'subImprimeCelula(IniCaixaX, FimCaixaX, IniCaixaY, FimCaixaY, Titulo, Negrito)
'    subImprimeBox IniCaixaX, IniCaixaY, FimCaixaX, FimCaixaY
'    Printer.CurrentY = IniCaixaY + 0.1
'    GuardaY = Printer.CurrentY
'
'    subImprimeTexto Titulo, (IniCaixaX + 0.2), GuardaY, 5, "Times New Roman", False, False
'
'    GuardaY = Printer.CurrentY + DistanciaTitCampo
'    If xcampo = "Titulo" Then
'        Printer.CurrentY = GuardaY
'        RecebeCampo = QFields(XData, "Titulo")
'        CriaVetorObs RecebeCampo, (IniCaixaX + 0.2), 58, 8, Negrito, False
'    ElseIf xcampo = "Devolvido" Then
'        If QFields(XData, "Devolvido") = "S" Then
'            subImprimeTexto "Devolvido", (IniCaixaX + 0.2), GuardaY, 8, "Times New Roman", Negrito, False
'        Else
'            subImprimeTexto "N�o Devolvido", (IniCaixaX + 0.2), GuardaY, 8, "Times New Roman", Negrito, False
'        End If
'    Else
'        RecebeCampo = QFields(XData, xcampo)
'        subImprimeTexto funNulo(RecebeCampo), (IniCaixaX + 0.2), GuardaY, 8, "Times New Roman", Negrito, False
'    End If
    
End Sub

Sub subCabecalho_Listagem(Titulo As String)
    Printer.CurrentY = 1.5
    Printer.Line (2.1, 1.5)-((Len(Titulo) / 2.5) + 0.1, 2.2), QBColor(0), BF
    Printer.FillStyle = 0
    Printer.DrawStyle = 5
    Printer.FillColor = RGB(240, 240, 240)
    Printer.Line (2, 1.4)-(Len(Titulo) / 2.5, 2.1), , B
    Printer.FillColor = RGB(250, 250, 250)
    Printer.DrawStyle = 0
    Printer.FillStyle = 1
    Printer.CurrentY = 1.5
    subImprimeTexto Titulo, 2.2, Printer.CurrentY, 13, "Times New Roman", True, False
    Printer.CurrentY = 3
    AltCabecalho = 3
End Sub

Sub subCabecalhoListagemRelatorio(Titulo As String)
    Printer.CurrentY = 1
'    If PLogo <> "" Then
'        Printer.PaintPicture LoadPicture(PLogo), 2, 1, 30, 5.5, , , 38.36, 7.28
'    End If
    subImprimeTexto PEmpresa, 6, Printer.CurrentY, 16, "Times New Roman", True, True
    'subImprimeTexto PEndereco, 6, Printer.CurrentY, 10, "Times New Roman", False, False
    subImprimeTexto Titulo, 6, Printer.CurrentY, 15, "Times New Roman", True, False
    Printer.CurrentY = 4
    AltCabecalho = 4
End Sub


Sub subCabecalho_Listagem_Relatorio(Titulo As String)
    Printer.CurrentY = 1
'    If PLogo <> "" Then
'        Printer.PaintPicture LoadPicture(PLogo), 2, 1, 30, 5.5, , , 38.36, 7.28
'    End If
    subImprimeTexto PEmpresa, 6, Printer.CurrentY, 16, "Times New Roman", True, True
    subImprimeTexto PEndereco, 6, Printer.CurrentY, 10, "Times New Roman", False, False
    subImprimeTexto Titulo, 6, Printer.CurrentY, 15, "Times New Roman", True, False
    Printer.CurrentY = 4
    AltCabecalho = 4
End Sub

Sub subImprimeLinha(XInicio As Single, XFim As Single, Espessura As Double)
    Printer.DrawWidth = Espessura     'Definida em Pixels
    Printer.Line (XInicio, Printer.CurrentY)-(XFim, Printer.CurrentY), QBColor(0) ', BF
End Sub

Sub subImprimeTexto(cabecalho As String, ByVal X As Single, ByVal y As Single, Tamanho As Long, Font As String, Negrito As Boolean, Italico As Boolean)
    'Printer.ScaleMode = vbCentimeters
    Printer.CurrentX = X
    Printer.CurrentY = y
    Printer.Font.Name = Font
    Printer.Font.Size = Tamanho
    Printer.Font.Bold = Negrito
    Printer.Font.Italic = Italico
    'Printer.FontTransparent = False
    
    Printer.Print cabecalho
End Sub
Sub subCompletaCampo(RecebeCampo As String, XFim As Single, Negrito As Boolean)
    'Valor do cheque por extenso
      
'      GuardaY = Printer.CurrentY

      'Dim XFim As Single,
      Dim final As Integer, X As Integer
      Dim linha1 As String
      Dim linha2 As String
  
      'XFim = 17 - ResPadrao!banc_vl_colext 'em centimetros
      final = Len(RecebeCampo)
      If Printer.TextWidth(RecebeCampo) > XFim Then
         While Printer.TextWidth(RecebeCampo) > XFim
            linha2 = RecebeCampo
            RecebeCampo = Left(RecebeCampo, 50)
            linha2 = Right(linha2, final - XFim)
         Wend '
         'Do While Mid(RecebeCampo, final, 1) <> " " And (Printer.TextWidth(Left(RecebeCampo , (Len(RecebeCampo) - final))) > XFim)
         '   final = final - 1
         'Loop
         linha1 = Mid(RecebeCampo, 1, final)
         linha2 = Mid(RecebeCampo, final + 1, Len(RecebeCampo) - final)
         
      Else
         linha1 = RecebeCampo
         linha2 = ""
      End If
      linha1 = Trim(linha1)
      linha2 = Trim(linha2)
      If Printer.TextWidth(linha1) < XFim And linha2 = "" Then
         While Printer.TextWidth(linha1) < XFim
           linha1 = linha1 + "*"
         Wend
      End If
      If Printer.TextWidth(linha2) < (XFim + 2) Then
         While Printer.TextWidth(linha2) < (XFim + 2)
           linha2 = linha2 + "*"
         Wend
      End If
      subImprimeTexto linha1, Printer.CurrentX, Printer.CurrentY, 9, "arial", Negrito, False
      If linha1 <> linha2 Then
       subImprimeTexto linha2, Printer.CurrentX, Printer.CurrentY, 9, "arial", Negrito, False
      End If
End Sub
Function subImprimePromissoria(Cont As Long, XLS_Obs As String, XLI_Clausula As Integer, XLO_RSTITU As ADODB.Recordset, XLO_RSCONFIG As ADODB.Recordset, XLD_DATA As Date, XLT_FONT As String)
    Dim TamanhoPapel As Single
    Dim LargPapel As Single, AltPapel As Single
    Dim RecebeCampo As String
    Dim XLB_Negrito As Boolean
    Dim XLS_Campo As String
    Dim aux As Boolean
        
    'Cont - seta o numero do documento a ser impresso. recebe o acumulo da altura do documento

    aux = True
    TamanhoPapel = Printer.PaperSize
    LargPapel = 17.5 / 567 'Convertendo Twips para Cms
    AltPapel = 7.6 / 567 'Convertendo Twips para Cms
    While Not (XLO_RSCONFIG.EOF)
      If Not (XLO_RSCONFIG!form_nr_negrito = -1) Then
        XLB_Negrito = False
      Else
        XLB_Negrito = True
      End If
      Printer.Font.Bold = XLB_Negrito
      Printer.Font.Size = XLO_RSCONFIG!form_nr_tamfonte
      Printer.Font.Name = XLT_FONT
      XLS_Campo = XLO_RSCONFIG!form_tx_nomecampo
            
      Select Case (XLS_Campo)
      'campos que nao estao na consulta ( datas e valores por extenso )
          Case "ValorTitulo"
            If Not (XLO_RSCONFIG!form_tx_Descricao = "Valor do T�tulo") Then
              RecebeCampo = funExtenso(XLO_RSTITU.Fields(XLS_Campo))
                If XLI_Clausula = 1 Then
                  Printer.CurrentY = Cont + XLO_RSCONFIG!form_nr_altura
                  Printer.CurrentX = XLO_RSCONFIG!form_nr_largura
                  RecebeCampo = RecebeCampo & " REAJUSTADOS CONFORME O PACTUADO EM CONTRATO"
                  RecebeCampo = RecebeCampo & " *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** "
                  subQuebraTexto RecebeCampo, XLO_RSCONFIG!form_nr_largura, 15, XLO_RSCONFIG!form_nr_tamfonte, XLT_FONT, XLO_RSCONFIG!form_nr_negrito, False
                Else
                  Printer.CurrentY = Cont + XLO_RSCONFIG!form_nr_altura
                  Printer.CurrentX = XLO_RSCONFIG!form_nr_largura
                  RecebeCampo = RecebeCampo & " *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***  *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***"
                  subQuebraTexto RecebeCampo, XLO_RSCONFIG!form_nr_largura, 15, XLO_RSCONFIG!form_nr_tamfonte, XLT_FONT, XLO_RSCONFIG!form_nr_negrito, False
                End If
            Else
              RecebeCampo = Format$(XLO_RSTITU.Fields(XLS_Campo), "##,##0.00")
            End If
          Case "Observacao"
            If Not (XLS_Obs = "" Or IsNull(XLS_Obs)) Then
              RecebeCampo = XLS_Obs
            Else
              RecebeCampo = ""
            End If
            
          Case "DataVenc"
            Select Case (XLO_RSCONFIG!form_tx_Descricao)
              Case "Dia do Vencimento - 2 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " dd")
              Case "M�s do Vencimento - Extenso"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "mmmm ")
              Case "Ano do Vencimento - 4 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "yyyy ")
              Case "Data do Vencimento - Exenso"
                'RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd             mmmm             yyyy")
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd \dia\s \do \m�\s \de mmmm \do a\no \de yyyy")
              Case "Ano do Vencimento - 2 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "yy ")
              Case Else
                RecebeCampo = FunNulo(XLO_RSTITU.Fields(XLS_Campo))
            End Select
          
          Case "DataVenda"
            Select Case (XLO_RSCONFIG!form_tx_Descricao)
              Case "Dia da venda - 2 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " dd")
              Case "M�s da venda - Extenso"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " mmmm ")
              Case "Ano da venda - 4 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "yyyy ")
              Case "Data da venda - Exenso"
                'RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " dd             mmmm             yyyy")
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd \dia\s \do \m�\s \de mmmm \do a\no \de yyyy")
              Case "Ano da venda - 2 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "yy ")
            Case Else
              RecebeCampo = FunNulo(XLO_RSTITU.Fields(XLS_Campo))
            End Select
          
          Case "DataRegCont"
            Select Case (XLO_RSCONFIG!form_tx_Descricao)
              Case "Dia do Registro Cont. - 2 Dig"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd")
              Case "M�s do Registro Cont - Extenso"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " mmmm ")
              Case "Ano Registro Cont. - 4 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " yyyy ")
              Case "Data Registro Cont. - Extenso"
                'RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd         mmmm             yyyy")
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "dd \dia\s \do \m�\s \de mmmm \do a\no \de yyyy")
              Case "Ano Registro Cont. - 2 D�gitos"
                RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), " yy ")
            Case Else
              RecebeCampo = FunNulo(XLO_RSTITU.Fields(XLS_Campo))
            End Select
            
            Case "DataAtual"
            Select Case (XLO_RSCONFIG!form_tx_Descricao)
              Case "Dia Atual"
                RecebeCampo = Format(XLD_DATA, "dd")
              Case "M�s Atual - Extenso"
                RecebeCampo = Format(XLD_DATA, "mmmm")
              Case "Ano Atual - 4 D�gitos"
                RecebeCampo = Format(XLD_DATA, "yyyy")
              Case "Data Atual - Extenso"
                'RecebeCampo = Format(XLD_DATA, "dd             mmmm                     yyyy")
                RecebeCampo = Format(XLD_DATA, "dd \dia\s \do \m�\s \de mmmm \do a\no \de yyyy")
              Case "Ano Atual - 2 D�gitos"
                RecebeCampo = Format(XLD_DATA, "yy")
              Case Else
                RecebeCampo = FunNulo(Format(XLD_DATA, "dd/mm/yyyy"))
            End Select
            
          Case "JurosFin"
            RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "##0.0000")
          
          Case "Cotacao"
            RecebeCampo = Format(FunNuloVal(XLO_RSTITU.Fields(XLS_Campo)), "##0.0000")
            
          Case "ValorIndexado"
            RecebeCampo = Format(XLO_RSTITU.Fields(XLS_Campo), "##0.0000")
            
        Case Else
          RecebeCampo = FunNulo(XLO_RSTITU.Fields(XLS_Campo))
      End Select
      'bufferiza o docuento a ser impresso
      If aux Then
        subImprimeTexto RecebeCampo, XLO_RSCONFIG!form_nr_largura, Cont + XLO_RSCONFIG!form_nr_altura, XLO_RSCONFIG!form_nr_tamfonte, XLT_FONT, XLO_RSCONFIG!form_nr_negrito, False
        aux = True
      End If
      XLO_RSCONFIG.MoveNext
        
    Wend
    
'If Not XLO_RsConfig.EOF Then
  XLO_RSCONFIG.MoveFirst
'End If

End Function

Function funExtenso(XNum As Double) As String

'Esta fun��o retorna um valor por extenso

Dim T(4) As String
Dim V(4) As String
Dim p(4) As String
Dim S(4) As String
Dim N(900) As String
Dim Texto As String
Dim xNumero, num1, num2, num3, num4 As String
Dim X As Integer
Dim Status, Primeiro As Boolean
Texto = ""
N(1) = "UM "
N(2) = "DOIS "
N(3) = "TRES "
N(4) = "QUATRO "
N(5) = "CINCO "
N(6) = "SEIS "
N(7) = "SETE "
N(8) = "OITO "
N(9) = "NOVE "
N(10) = "DEZ "
N(11) = "ONZE "
N(12) = "DOZE "
N(13) = "TREZE "
N(14) = "QUATORZE "
N(15) = "QUINZE "
N(16) = "DEZESSEIS "
N(17) = "DEZESSETE "
N(18) = "DEZOITO "
N(19) = "DEZENOVE "
N(20) = "VINTE "
N(30) = "TRINTA "
N(40) = "QUARENTA "
N(50) = "CINQUENTA "
N(60) = "SESSENTA "
N(70) = "SETENTA "
N(80) = "OITENTA "
N(90) = "NOVENTA "
N(0) = "CEM "
N(100) = "CENTO "
N(200) = "DUZENTOS "
N(300) = "TREZENTOS "
N(400) = "QUATROCENTOS "
N(500) = "QUINHENTOS "
N(600) = "SEISCENTOS "
N(700) = "SETECENTOS "
N(800) = "OITOCENTOS "
N(900) = "NOVECENTOS "
T(4) = "BILHAO "
T(3) = "MILHAO "
T(2) = "MIL "
T(1) = ""
V(4) = "BILHOES "
V(3) = "MILHOES "
V(2) = "MIL "
V(1) = ""
xNumero = Right((Space(12) + Trim(Str(Int(XNum)))), 12)
p(4) = Mid(xNumero, 1, 3)
p(3) = Mid(xNumero, 4, 3)
p(2) = Mid(xNumero, 7, 3)
p(1) = Mid(xNumero, 10, 3)
'p(0) = Trim(Str(Round(XNum, 2) * 100 - Round(XNum) * 100))
p(0) = Right(Trim(Str((Round(XNum, 2) * 100))), 2)
S(4) = Val(p(4) + "000000000.00")
S(3) = Val(p(4) + p(3) + "000000.00")
S(2) = Val(p(4) + p(3) + p(2) + "000.00")
S(1) = Val(p(4) + p(3) + p(2) + p(1) + ".00")
For X = 4 To 1 Step -1
    If Val(p(X)) <> 0 Then
       num1 = Trim(Mid(p(X), 1, 1))
       num2 = Trim(Mid(p(X), 2, 1))
       num3 = Trim(Mid(p(X), 3, 1))
       Status = IIf(num2 <> "1", True, False)
       Primeiro = True
       If num1 <> "" And num1 <> "0" Then
          If num1 = "1" And num2 + num3 = "00" Then
             num1 = "000"
          Else
             num1 = num1 + "00"
          End If
          If XNum > S(X) Then
             Texto = IIf(Texto <> "", Trim(Texto) + ", " + N(Val(num1)), Texto + N(Val(num1)))
          Else
             Texto = IIf(Texto <> "", Texto + "E " + N(Val(num1)), Texto + N(Val(num1)))
          End If
          Primeiro = False
       End If
       If num2 <> "" And num2 <> "0" Then
          num2 = IIf(Status, num2 + "0", num2 + num3)
          If Primeiro And XNum > S(X) Then
             Texto = IIf(Texto <> "", Trim(Texto) + ", " + N(Val(num2)), Texto + N(Val(num2)))
          Else
             Texto = IIf(Texto <> "", Texto + "E " + N(Val(num2)), Texto + N(Val(num2)))
          End If
          Primeiro = False
       End If
       If num3 <> "" And num3 <> "0" And Status Then
          If Primeiro And XNum > S(X) Then
             Texto = IIf(Texto <> "", Trim(Texto) + ", " + N(Val(num3)), Texto + N(Val(num3)))
          Else
             Texto = IIf(Texto <> "", Texto + "E " + N(Val(num3)), Texto + N(Val(num3)))
          End If
       End If
       Texto = IIf(Val(p(X)) = 1, Texto + T(X), Texto + V(X))
    End If
Next
If Val(xNumero) <> 0 Then
   If Val(xNumero) = 1 Then
      Texto = Texto + "REAL "
   ElseIf Val(p(2)) = 0 And Val(p(1)) = 0 Then
      Texto = Texto + "DE REAIS "
   Else
      Texto = Texto + "REAIS "
   End If
End If
If Val(p(0)) <> 0 Then
   num1 = Mid(p(0), 1, 1)
   num2 = Mid(p(0), 2, 1)
   If num1 <> "" And num1 <> "0" Then
      num4 = IIf(num1 <> "1", num1 + "0", num1 + num2)
      Texto = IIf(Texto <> "", Texto + "E " + N(Val(num4)), Texto + N(Val(num4)))
   End If
   If num2 <> "" And num2 <> "0" And num1 <> "1" Then
      Texto = IIf(Texto <> "", Texto + "E " + N(Val(num2)), Texto + N(Val(num2)))
   End If
   If Val(p(0)) = 1 Then
      Texto = Texto + "CENTAVO"
   Else
      Texto = Texto + "CENTAVOS"
   End If
End If
funExtenso = Texto

End Function


Sub subQuebraLinha(Texto As String, XInicio As Single, TamCampo As Single, TamLetra As Long, Fonte As String, Negrito As Boolean, Italico As Boolean)
    'feita por Daniel
    Dim Resto As String
    Dim ProcuraEspaco As Integer
        
    'Para Garantir Que Vai Verificar o Tamanho Com a Formata��o Correta
    Printer.Font.Name = Fonte
    Printer.Font.Size = TamLetra
    Printer.Font.Bold = Negrito
    Printer.Font.Italic = Italico
    
    Resto = ""
    Texto = Trim$(Texto)
    'Texto � uma vari�vel que indica a string a ser impressa, ap�s a impress�o o seu valor �
    'substitu�do pelo valor de Resto, se n�o existir Resto significa que j� foi impresso toda a
    'string, consequentemente o valor de texto tamb�m ser� vazio.
    
    'Se Texto for vazio imprime vazio e sai
    If Texto = "" Then
        subImprimeTexto Texto, XInicio, Printer.CurrentY, TamLetra, Fonte, Negrito, Italico
        Exit Sub
    End If
    
    While Texto <> ""
        'Enquanto o tamanho do Texto for maior que o tamanho do espa�o reservado para ele
        'ser� retirado o �ltimo caractere do Texto e este ser� acrescido a vari�vel Resto
        While Printer.TextWidth(Texto) > TamCampo
            Resto = Mid$(Texto, Len(Texto), 1) + Resto
            Texto = Mid$(Texto, 1, (Len(Texto) - 1))
        Wend
        
'*********************************************************************************************************
'Esta parte da sub � para impedir que se quebre uma palavra no meio
'*********************************************************************************************************
        'Se Resto for igual a vazio significa que n�o existir� uma pr�xima linha
        If Resto <> "" Then
            If Mid$(Resto, 1, 1) = " " Then 'Resto possui espa�o no in�cio quebrou uma palavra completa
                Resto = LTrim$(Resto)
            ElseIf Mid$(Texto, Len(Texto), 1) = " " Then 'Texto possui espa�o no fim
                Texto = RTrim$(Texto)                           'quebrou uma palavra completa
            Else 'Quebrou metade de uma palavra
                ProcuraEspaco = Len(Texto)
                'Verifica se Texto possui algum espa�o para quebrar a palavra completa
                While Mid$(Texto, ProcuraEspaco, 1) <> " " And ProcuraEspaco <> 1
                    ProcuraEspaco = ProcuraEspaco - 1
                Wend
                If ProcuraEspaco <> 1 Then
                    Resto = Right$(Texto, Len(Texto) - ProcuraEspaco) & Resto
                    Texto = RTrim$(Left(Texto, ProcuraEspaco))
                End If
            End If
        End If
'*********************************************************************************************************
        subImprimeTexto Texto, XInicio, Printer.CurrentY, TamLetra, Fonte, Negrito, Italico
        Texto = Resto
        Resto = ""
    Wend
End Sub



