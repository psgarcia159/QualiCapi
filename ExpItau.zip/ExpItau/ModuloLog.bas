Attribute VB_Name = "ModuloLog"
'Enumarator com as opera��es que ter�o log
Enum ENUM_OPERACOES
    'QualiFin
    ALTERAR
    ALTERAR_DUPLICATA
    ALTERAR_DESCONTO
    ALTERAR_DISTRIBUICAO
    BAIXA_PARCIAL  'Fazer pagamento parcial de uma duplicata
    CADASTRAR
    CADASTRAR_DUPLICATA
    CADASTRAR_DESCONTO
    CADASTRAR_DISTRIBUICAO
    CANCELAR 'Cancelar uma conta a pagar (nota fiscal) ou duplicata compromissada
    CANCELAR_ESTORNO
    DEVOLVER 'Devolu��o do valor total ou parcial de uma conta a pagar compromissada ou realizada: gera uma conta a receber realizada
    EFETIVAR 'Tornar uma duplicata realizada. Pode ser pela rotina de duplicatas ou de pagamentos.
    EFETIVAR_CONSOLIDADO
    ESTORNO 'Estorno de conta a pagar realizada.
    EXCLUIR
    EXCLUIR_DUPLICATA
    EXCLUIR_DESCONTO
    EXCLUIR_DISTRIBUICAO
    GLOSA 'Glosa de conta a receber compromissada.
    PENDENTE 'Cancelar o pagamento de uma duplicata, torn�-la compromissada.
    RECOLHER 'Recolher impostos de notas fiscais.
    TRANSFERENCIA
    PRESTAR_CONTAS
    RESTITUIR_ADIANTAMENTO 'Restitui��o de adiantamento pela rotina de presta��o de contas
    DEVOLVER_ADIANTAMENTO 'Devolu��o de adiantamento pela rotina de presta��o de contas
    EXPORTACAO_FIN
    IMPORTACAO_FIN
    EXPORTACAO_CAPI
    IMPORTACAO_CAPI
    IMPORTAR_FOLHA_NORMAL
    IMPORTAR_FOLHA_CPF
    IMPORTAR_FOLHA_CR
    IMPORTAR_FOLHA_PIS_FGTS
    IMPORTACAO_FOLHA_FUNCIONARIOS
    
    'QualiCapi
    ALTERACAO_MULTIPLA
    ATIVAR_CONTRATO
    CANCELAR_REPASSE_TITULO
    COPIAR
    CESSAO_CONTRATO
    DISTRATAR_CONTRATO
    EXCLUSAO_MULTIPLA
    RECALCULAR
    REPASSE_TITULO
    TRANSFERENCIA_ENTRE_EMPRESAS
    PAGTO_TITULO_DTDEPOSITO
        
    
    'ALTERAR_EMPREENDIMENTO
    'ALTERAR_IMOVEL
    'ALTERAR_TITULO
    'CADASTRAR_EMPREENDIMENTO
    'CADASTRAR_IMOVEL
    'CADASTRAR_TITULO
    'CADASTRAR_PLANO
    'EXCLUIR_EMPREENDIMENTO
    'EXCLUIR_IMOVEL
    
    PAGAMENTO_TITULO
    CANCELAR_PAGAMENTO_TITULO
End Enum

'Enumarator com as entidades que ter�o log
Enum ENUM_ENTIDADES
    
    'QualiFin
    IMPOSTO
    DISTRIBUICAO
    DUPLICATA
    MULTA_JURO
    NOTAFISCAL_RECEBER
    NOTAFISCAL_PAGAR
    FATURAS
    TRANSFERENCIA_BANCARIA
    TRANSFERENCIA_CUSTO
    PRESTACAO_CONTAS
    PAGAMENTO_CHEQUE
    PAGAMENTO_DEBITO_CREDITO
    PAGAMENTO_BORDERO
    
    'Exporta��o Banc�ria
    PAGAMENTO_ELETRONICO_ITAU
    PAGAMENTO_ELETRONICO_REAL
    PAGAMENTO_ELETRONICO_SANTANDER
    PAGAMENTO_ELETRONICO_SUDAMERIS
    PAGAMENTO_ELETRONICO_BRASIL
    PAGAMENTO_ELETRONICO_UNIBANCO
    PAGAMENTO_ELETRONICO_HSBC
    PAGAMENTO_ELETRONICO_CAIXA
    IMPORTACAO_FOLHA
    
    'QualiCapi
    CONTRATO_CAPI
    EMPREENDIMENTO_CAPI
    IMOVEL_CAPI
    PLANO_CAPI
    TITULO_CAPI
    PAGAMENTO_MULTIPLO_CAPI
    PAGAMENTO_UNICO_CAPI
    
End Enum

'Rotina para gravar log
'XLT_ROTINA: Nome da tela
'XLT_ORDEMROTINA: ordem da rotina na tabela Rotinas
Sub subRegistraLog(XLT_ROTINA As String, XLT_ORDEMROTINA As String, XLT_DESCRICAO As String)

    Dim XLO_COMANDO As New ADODB.Command 'Comando para stored procedure
    
    With XLO_COMANDO
        .CommandText = "sp_ins_Log"
        .CommandType = adCmdStoredProc
        Set XLO_COMANDO.ActiveConnection = ConexaoRelatorio
        'Cria automaticamente todos os par�metros dentro do objeto Comando
        .Parameters.Refresh
    End With
  
    'Adiciona os par�metros a procedure
    XLO_COMANDO.Parameters(1).Value = func_cd_operador
    XLO_COMANDO.Parameters(2).Value = XLT_ROTINA
    XLO_COMANDO.Parameters(3).Value = XLT_ORDEMROTINA
    XLO_COMANDO.Parameters(4).Value = XLT_DESCRICAO
     
    XLO_COMANDO.Execute
  
End Sub

'Rotina para criar descri��o do log
'XLM_MATRIZLOG: cont�m todos os dados utilizados para criar a descri��o do log. Col0: nome do campo; Col1: valores originais; Col2: valores atuais.
'XLT_OPERACAO: opera��o que ser� executada (inclus�o, efetivar...).
'XLT_ENTIDADE: entidade que ser� alterada (nota fiscal, fatura, etc).
Function funCriaDescricaoLog(ByVal XLM_MATRIZLOG As Variant, XLT_OPERACAO As ENUM_OPERACOES, XLT_ENTIDADE As ENUM_ENTIDADES) As String
    Dim Cont As Integer
    Dim registroAnterior As Object
    Dim descricao As String
     
    'Informa a empresa, a opera��o, a entidade e a identifica��o da entidade
    descricao = "Emp: " & PEmpresa & "; OPERA��O: " & funNomeOperacao(XLT_OPERACAO) & "; TELA: " & funNomeEntidade(XLT_ENTIDADE) & ";"
        
    'Descreve os campos apenas para altera��o e exclus�o.
    If XLT_OPERACAO = ALTERAR Or XLT_OPERACAO = ALTERAR_DESCONTO Or XLT_OPERACAO = ALTERAR_DISTRIBUICAO Or XLT_OPERACAO = ALTERAR_DUPLICATA Or XLT_OPERACAO = ALTERACAO_MULTIPLA Then
        'Preenche identifica��o da entidade antes de informar os campos alterados
        For Cont = 0 To 2
            descricao = descricao & " " + UCase(XLM_MATRIZLOG(Cont, 0)) & ": " & XLM_MATRIZLOG(Cont, 1) & ";"
        Next
        
        For Cont = 0 To (UBound(XLM_MATRIZLOG) - 1)
            If (XLM_MATRIZLOG(Cont, 1) <> XLM_MATRIZLOG(Cont, 2) And XLM_MATRIZLOG(Cont, 2) <> Empty) Then
                descricao = descricao & " " & UCase(XLM_MATRIZLOG(Cont, 0)) & " alterado de: " & UCase(XLM_MATRIZLOG(Cont, 1)) & " para: " & UCase(XLM_MATRIZLOG(Cont, 2)) & ";"
            End If
        Next
    Else
        For Cont = 0 To (UBound(XLM_MATRIZLOG) - 1)
            descricao = descricao & " " + UCase(XLM_MATRIZLOG(Cont, 0)) & ": " & XLM_MATRIZLOG(Cont, 1) & ";"
        Next
    End If
  
  funCriaDescricaoLog = descricao
End Function

'Fun��o para retornar o nome da opera��o como string
Function funNomeOperacao(enumerator As ENUM_OPERACOES)
    Select Case enumerator
        Case ALTERAR
            funNomeOperacao = "ALTERAR"
        Case ALTERAR_DESCONTO
            funNomeOperacao = "ALTERAR DESCONTO"
        Case ALTERAR_DISTRIBUICAO
            funNomeOperacao = "ALTERAR DISTRIBUICAO"
        Case ALTERAR_DUPLICATA
            funNomeOperacao = "ALTERAR DUPLICATA"
        Case BAIXA_PARCIAL
            funNomeOperacao = "BAIXA PARCIAL"
        Case CADASTRAR
            funNomeOperacao = "CADASTRAR"
        Case CADASTRAR_DESCONTO
            funNomeOperacao = "CADASTRAR DESCONTO"
        Case CADASTRAR_DISTRIBUICAO
            funNomeOperacao = "CADASTRAR DISTRIBUI��O"
        Case CADASTRAR_DUPLICATA
            funNomeOperacao = "CADASTRAR DUPLICATA"
        Case CANCELAR
            funNomeOperacao = "CANCELAR"
        Case CANCELAR_ESTORNO
            funNomeOperacao = "CANCELAR ESTORNO FINANCEIRO"
        Case DEVOLVER
            funNomeOperacao = "DEVOLUCAO"
        Case EFETIVAR
            funNomeOperacao = "EFETIVAR"
        Case EFETIVAR_CONSOLIDADO
            funNomeOperacao = "EFETIVAR CONSOLIDADO"
        Case ESTORNO
            funNomeOperacao = "ESTORNO FINANCEIRO"
        Case EXCLUIR
            funNomeOperacao = "EXCLUIR"
        Case EXCLUIR_DESCONTO
            funNomeOperacao = "EXCLUIR DESCONTO"
        Case EXCLUIR_DISTRIBUICAO
            funNomeOperacao = "EXCLUIR DISTRIBUI��O"
        Case EXCLUIR_DUPLICATA
            funNomeOperacao = "EXCLUIR DUPLICATA"
        Case GLOSA
            funNomeOperacao = "GLOSA"
        Case PENDENTE
            funNomeOperacao = "CANCELAR PAGAMENTO"
        Case RECOLHER
            funNomeOperacao = "RECOLHER"
        Case TRANSFERENCIA
            funNomeOperacao = "TRANSFER�NCIA"
        Case PRESTAR_CONTAS
            funNomeOperacao = "PRESTAR CONTAS"
        Case RESTITUIR_ADIANTAMENTO
            funNomeOperacao = "RESTITUIR ADIANTAMENTO"
        Case DEVOLVER_ADIANTAMENTO
            funNomeOperacao = "DEVOLVER ADIANTAMENTO"
        Case EXPORTACAO_FIN
            funNomeOperacao = "EXPORTA��O BANC�RIA QUALIFIN"
        Case EXPORTACAO_CAPI
            funNomeOperacao = "EXPORTA��O BANC�RIA QUALICAPI"
        Case IMPORTACAO_FIN
            funNomeOperacao = "IMPORTA��O BANC�RIA QUALIFIN"
        Case IMPORTACAO_CAPI
            funNomeOperacao = "IMPORTA��O BANC�RIA QUALICAPI"
        Case IMPORTAR_FOLHA_NORMAL
            funNomeOperacao = "IMPORTA��O DE FOLHA DE PAGAMENTO NORMAL"
        Case IMPORTAR_FOLHA_CPF
            funNomeOperacao = "IMPORTA��O DE FOLHA DE PAGAMENTO POR CPF"
        Case IMPORTAR_FOLHA_CR
            funNomeOperacao = "IMPORTA��O DE FOLHA DE PAGAMENTO POR CR"
        Case IMPORTAR_FOLHA_PIS_FGTS
            funNomeOperacao = "IMPORTA��O DE FOLHA PIS/FGTS"
        Case IMPORTAR_FOLHA_FUNCIONARIOS
            funNomeOperacao = "IMPORTA��O DE FUNCION�RIOS"
        Case ATIVAR_CONTRATO
            funNomeOperacao = "ATIVAR CONTRATO INATIVO"
        Case CESSAO_CONTRATO
            funNomeOperacao = "CESS�O DE CONTRATO"
        Case TRANSFERENCIA_ENTRE_EMPRESAS
            funNomeOperacao = "TRANSFER�NCIA ENTRE EMPRESAS"
        Case EXCLUSAO_MULTIPLA
            funNomeOperacao = "EXCLUS�O M�LTIPLA"
        Case RECALCULAR
            funNomeOperacao = "RECALCULAR"
        Case REPASSE_TITULO
            funNomeOperacao = "REPASSE DE T�TULO"
        Case CANCELAR_REPASSE_TITULO
            funNomeOperacao = "CANCELAR REPASSE DE T�TULO"
        Case ALTERACAO_MULTIPLA
            funNomeOperacao = "ALTERA��O M�LTIPLA"
        Case DISTRATAR_CONTRATO
            funNomeOperacao = "DISTRATO DE CONTRATO"
        Case COPIAR
            funNomeOperacao = "COPIAR"
        Case PAGTO_TITULO_DTDEPOSITO
            funNomeOperacao = "PAGTO DE T�TULO COM DT D�POSITO MAIOR QUE DT PAGAMENTO"
        Case CANCELAR_PAGAMENTO_TITULO
            funNomeOperacao = "CANCELAMENTO DE PAGTO DE T�TULO"
        Case PAGAMENTO_TITULO
            funNomeOperacao = "PAGAMENTO DE T�TULO"
    End Select
End Function

Function funNomeEntidade(enumerator As ENUM_ENTIDADES)
    Select Case enumerator
        Case IMPOSTO
            funNomeEntidade = "DESCONTO"
        Case DISTRIBUICAO
            funNomeEntidade = "DISTRIBUICAO"
        Case DUPLICATA
            funNomeEntidade = "DUPLICATA"
        Case MULTA_JURO
            funNomeEntidade = "MULTA JURO"
        Case NOTAFISCAL_RECEBER
            funNomeEntidade = "CONTAS A RECEBER"
        Case NOTAFISCAL_PAGAR
            funNomeEntidade = "CONTAS A PAGAR"
        Case FATURAS
            funNomeEntidade = "FATURA"
        Case TRANSFERENCIA_BANCARIA
            funNomeEntidade = "TRANSFER�NCIA BANC�RIA"
        Case TRANSFERENCIA_CUSTO
            funNomeEntidade = "TRANSFER�NCIA DE CUSTO"
        Case PRESTACAO_CONTAS
            funNomeEntidade = "PRESTA��O DE CONTAS"
        Case PAGAMENTO_CHEQUE
            funNomeEntidade = "PAGAMENTO CHEQUE"
        Case PAGAMENTO_DEBITO_CREDITO
            funNomeEntidade = "PAGAMENTO D�BITO/CR�DITO EM CONTA"
        Case PAGAMENTO_BORDERO
            funNomeEntidade = "PAGAMENTO BORDER�"
        Case PAGAMENTO_ELETRONICO_ITAU
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO ITA�"
        Case PAGAMENTO_ELETRONICO_REAL
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO REAL"
        Case PAGAMENTO_ELETRONICO_SANTANDER
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO SANTANDER"
        Case PAGAMENTO_ELETRONICO_SUDAMERIS
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO SUDAMERIS"
        Case PAGAMENTO_ELETRONICO_BRASIL
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO DO BRASIL"
        Case PAGAMENTO_ELETRONICO_UNIBANCO
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO UNIBANCO"
        Case PAGAMENTO_ELETRONICO_HSBC
            funNomeEntidade = "PAGAMENTO ELETR�NICO BANCO HSBC"
        Case IMPORTACAO_FOLHA
            funNomeEntidade = "IMPORTA��O DE FOLHA DE PAGAMENTO"
        Case EMPREENDIMENTO_CAPI
            funNomeEntidade = "EMPREENDIMENTOS"
        Case IMOVEL_CAPI
            funNomeEntidade = "IM�VEIS"
        Case CONTRATO_CAPI
            funNomeEntidade = "CONTRATOS"
        Case TITULO_CAPI
            funNomeEntidade = "T�TULOS"
    End Select
End Function

